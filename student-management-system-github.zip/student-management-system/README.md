# Student Management System

A student register built with HTML, CSS and JavaScript, a Python Flask REST API, and SQLite.

## Project structure

```text
student-management-system/
├── app.py
├── requirements.txt
├── test_app.py
├── README.md
├── .gitignore
└── static/
    ├── index.html
    ├── script.js
    └── style.css
```

The SQLite database (`students.db`) is created automatically when the app starts. It is intentionally excluded from Git because it may contain personal student information.

## Run locally

1. Install Python 3.9 or newer.
2. Create and activate a virtual environment (recommended).
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   python app.py
   ```

5. Open http://127.0.0.1:5000 in your browser.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | List students; optional `?q=` search by name or roll number |
| GET | `/api/students/<id>` | Get one student |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/<id>` | Update a student |
| DELETE | `/api/students/<id>` | Delete a student |

## Validation

- All fields are required.
- Roll numbers must be unique and contain only letters, digits or hyphens.
- Contact numbers must be valid 10-digit Indian mobile numbers.
- Marks must be between 0 and 100.

## Tests

Run `python test_app.py` to execute the included API checks. **The test script deletes the local `students.db` file before running**, so back up any database you want to keep before running it.

## Deployment note

This is a Flask + SQLite application, not a static-only website. GitHub stores the source code but GitHub Pages cannot run the Flask backend. To make the app publicly accessible, deploy the Flask application to a Python hosting service and use persistent storage for the SQLite database (or a managed database).
