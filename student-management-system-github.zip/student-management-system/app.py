"""
Student Management System - Backend (Python Flask + SQLite)
Run:  python app.py   ->  open http://127.0.0.1:5000
"""
import os
import re
import sqlite3
from flask import Flask, jsonify, request, g, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "students.db")

app = Flask(__name__, static_folder="static", static_url_path="/static")


# ---------- Database helpers ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS students (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                roll_no    TEXT    NOT NULL UNIQUE,
                name       TEXT    NOT NULL,
                class_name TEXT    NOT NULL,
                marks      REAL    NOT NULL CHECK (marks >= 0 AND marks <= 100),
                contact    TEXT    NOT NULL,
                created_at TEXT    DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


# ---------- Validation ----------
def validate(data):
    """Returns (clean_dict, error_message)."""
    if not isinstance(data, dict):
        return None, "Invalid JSON body."
    roll_no = str(data.get("roll_no", "")).strip()
    name = str(data.get("name", "")).strip()
    class_name = str(data.get("class_name", "")).strip()
    contact = str(data.get("contact", "")).strip()
    marks_raw = data.get("marks", "")

    if not roll_no or not name or not class_name or not contact or marks_raw in ("", None):
        return None, "All fields are required."
    if not re.fullmatch(r"[A-Za-z0-9\-]{1,15}", roll_no):
        return None, "Roll number can contain letters, digits and hyphens only."
    if not re.fullmatch(r"[A-Za-z .'-]{2,60}", name):
        return None, "Name must be 2-60 letters."
    if not re.fullmatch(r"[6-9]\d{9}", contact):
        return None, "Contact must be a valid 10-digit mobile number."
    try:
        marks = float(marks_raw)
    except (TypeError, ValueError):
        return None, "Marks must be a number."
    if not 0 <= marks <= 100:
        return None, "Marks must be between 0 and 100."

    return {
        "roll_no": roll_no, "name": name, "class_name": class_name,
        "marks": marks, "contact": contact,
    }, None


def row_to_dict(row):
    return {k: row[k] for k in row.keys()}


# ---------- Frontend ----------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# ---------- REST API ----------
@app.route("/api/students", methods=["GET"])
def list_students():
    """List all students, or search with ?q=<name or roll no>."""
    q = request.args.get("q", "").strip()
    db = get_db()
    if q:
        like = f"%{q}%"
        rows = db.execute(
            "SELECT * FROM students WHERE name LIKE ? OR roll_no LIKE ? ORDER BY roll_no",
            (like, like),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM students ORDER BY roll_no").fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.route("/api/students/<int:student_id>", methods=["GET"])
def get_student(student_id):
    row = get_db().execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if row is None:
        return jsonify({"error": "Student not found."}), 404
    return jsonify(row_to_dict(row))


@app.route("/api/students", methods=["POST"])
def add_student():
    clean, err = validate(request.get_json(silent=True))
    if err:
        return jsonify({"error": err}), 400
    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO students (roll_no, name, class_name, marks, contact) VALUES (?,?,?,?,?)",
            (clean["roll_no"], clean["name"], clean["class_name"], clean["marks"], clean["contact"]),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": f"Roll number {clean['roll_no']} already exists."}), 409
    row = db.execute("SELECT * FROM students WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(row_to_dict(row)), 201


@app.route("/api/students/<int:student_id>", methods=["PUT"])
def update_student(student_id):
    clean, err = validate(request.get_json(silent=True))
    if err:
        return jsonify({"error": err}), 400
    db = get_db()
    if db.execute("SELECT 1 FROM students WHERE id = ?", (student_id,)).fetchone() is None:
        return jsonify({"error": "Student not found."}), 404
    try:
        db.execute(
            "UPDATE students SET roll_no=?, name=?, class_name=?, marks=?, contact=? WHERE id=?",
            (clean["roll_no"], clean["name"], clean["class_name"], clean["marks"],
             clean["contact"], student_id),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": f"Roll number {clean['roll_no']} already exists."}), 409
    row = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    return jsonify(row_to_dict(row))


@app.route("/api/students/<int:student_id>", methods=["DELETE"])
def delete_student(student_id):
    db = get_db()
    cur = db.execute("DELETE FROM students WHERE id = ?", (student_id,))
    db.commit()
    if cur.rowcount == 0:
        return jsonify({"error": "Student not found."}), 404
    return jsonify({"message": "Student deleted."})


init_db()

if __name__ == "__main__":
    app.run(debug=True)
