"""Run: python test_app.py  - quick API tests incl. edge cases."""
import os, app as m
if os.path.exists(m.DB_PATH): os.remove(m.DB_PATH)
m.init_db()
c = m.app.test_client()
good = {"roll_no":"23CS014","name":"Aarav Patil","class_name":"SE-B","marks":82.5,"contact":"9876543210"}

def check(label, cond):
    print(("PASS" if cond else "FAIL"), "-", label); assert cond

r = c.post("/api/students", json=good); check("add student -> 201", r.status_code == 201)
sid = r.get_json()["id"]
check("duplicate roll no -> 409", c.post("/api/students", json=good).status_code == 409)
check("bad contact -> 400", c.post("/api/students", json={**good,"roll_no":"X1","contact":"123"}).status_code == 400)
check("marks > 100 -> 400", c.post("/api/students", json={**good,"roll_no":"X2","marks":150}).status_code == 400)
check("missing field -> 400", c.post("/api/students", json={"name":"A"}).status_code == 400)
check("list returns 1", len(c.get("/api/students").get_json()) == 1)
check("search by name", len(c.get("/api/students?q=aarav").get_json()) == 1)
check("search non-existent -> empty", c.get("/api/students?q=zzz").get_json() == [])
r = c.put(f"/api/students/{sid}", json={**good,"marks":90}); check("update -> 200 & value", r.get_json()["marks"] == 90)
check("update non-existent -> 404", c.put("/api/students/999", json=good).status_code == 404)
check("delete -> 200", c.delete(f"/api/students/{sid}").status_code == 200)
check("delete non-existent -> 404", c.delete(f"/api/students/{sid}").status_code == 404)
check("homepage served", c.get("/").status_code == 200)
print("All tests passed")
