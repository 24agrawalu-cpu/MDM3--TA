// Student Register - Frontend logic (Fetch API, no page reloads)
const API = "/api/students";

const form = document.getElementById("student-form");
const idField = document.getElementById("student-id");
const errorBox = document.getElementById("form-error");
const saveBtn = document.getElementById("save-btn");
const cancelBtn = document.getElementById("cancel-btn");
const formTitle = document.getElementById("form-title");
const rowsEl = document.getElementById("rows");
const emptyEl = document.getElementById("empty");
const countEl = document.getElementById("count");
const searchEl = document.getElementById("search");
const toastEl = document.getElementById("toast");

const fields = ["roll_no", "name", "class_name", "marks", "contact"];
let students = [];

// ---------- helpers ----------
function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  setTimeout(() => toastEl.classList.remove("show"), 2200);
}

function showError(msg, fieldId) {
  errorBox.textContent = msg;
  errorBox.hidden = !msg;
  fields.forEach(f => document.getElementById(f).classList.remove("invalid"));
  if (fieldId) document.getElementById(fieldId).classList.add("invalid");
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function request(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

// ---------- client-side validation ----------
function validateForm(v) {
  if (!v.roll_no) return ["Enter a roll number.", "roll_no"];
  if (!/^[A-Za-z0-9-]{1,15}$/.test(v.roll_no)) return ["Roll number can have letters, digits and hyphens only.", "roll_no"];
  if (!/^[A-Za-z .'-]{2,60}$/.test(v.name)) return ["Name must be 2-60 letters.", "name"];
  if (!v.class_name) return ["Enter the class.", "class_name"];
  if (v.marks === "" || isNaN(v.marks) || v.marks < 0 || v.marks > 100) return ["Marks must be between 0 and 100.", "marks"];
  if (!/^[6-9]\d{9}$/.test(v.contact)) return ["Contact must be a valid 10-digit mobile number.", "contact"];
  return null;
}

// ---------- rendering ----------
function render() {
  rowsEl.innerHTML = students.map(s => `
    <tr>
      <td>${escapeHtml(s.roll_no)}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.class_name)}</td>
      <td class="num ${s.marks >= 40 ? "pass" : "fail"}">${s.marks}</td>
      <td class="num">${escapeHtml(s.contact)}</td>
      <td class="btns">
        <button class="small" data-edit="${s.id}">Edit</button>
        <button class="small danger" data-delete="${s.id}">Delete</button>
      </td>
    </tr>`).join("");

  countEl.textContent = `(${students.length})`;
  const q = searchEl.value.trim();
  emptyEl.hidden = students.length > 0;
  if (!students.length) {
    emptyEl.textContent = q ? `No student matches "${q}".` : "No students yet. Add the first one using the form.";
  }
}

async function load() {
  const q = searchEl.value.trim();
  try {
    students = await request(q ? `${API}?q=${encodeURIComponent(q)}` : API);
    render();
  } catch (e) { toast(e.message); }
}

// ---------- form mode ----------
function resetForm() {
  form.reset();
  idField.value = "";
  formTitle.textContent = "Add student";
  saveBtn.textContent = "Add student";
  cancelBtn.hidden = true;
  showError("");
}

function startEdit(id) {
  const s = students.find(x => x.id === id);
  if (!s) return;
  idField.value = s.id;
  fields.forEach(f => (document.getElementById(f).value = s[f]));
  formTitle.textContent = "Edit student";
  saveBtn.textContent = "Save changes";
  cancelBtn.hidden = false;
  showError("");
  document.getElementById("roll_no").focus();
}

// ---------- events ----------
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const values = Object.fromEntries(fields.map(f => [f, document.getElementById(f).value.trim()]));
  const problem = validateForm(values);
  if (problem) return showError(problem[0], problem[1]);

  const editing = idField.value !== "";
  try {
    await request(editing ? `${API}/${idField.value}` : API, {
      method: editing ? "PUT" : "POST",
      body: JSON.stringify(values),
    });
    toast(editing ? "Changes saved" : "Student added");
    resetForm();
    load();
  } catch (err) {
    showError(err.message, /Roll number/.test(err.message) ? "roll_no" : null);
  }
});

cancelBtn.addEventListener("click", resetForm);

rowsEl.addEventListener("click", async (e) => {
  const editId = e.target.dataset.edit;
  const delId = e.target.dataset.delete;
  if (editId) startEdit(Number(editId));
  if (delId) {
    const s = students.find(x => x.id === Number(delId));
    if (!confirm(`Delete ${s.name} (${s.roll_no})?`)) return;
    try {
      await request(`${API}/${delId}`, { method: "DELETE" });
      toast("Student deleted");
      if (idField.value === delId) resetForm();
      load();
    } catch (err) { toast(err.message); load(); }
  }
});

let timer;
searchEl.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(load, 250); });

load();
